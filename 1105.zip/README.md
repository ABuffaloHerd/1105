# 1105
 Website about the benefits and effects of streaming.

 ## Focus points
 ### Copyright
 > You know all the hoo hah with twitch and dmca. Yeah that stuff

 ### Entrepreneurship 
 > People gotta make money right? Even if it means using the _wrong_ platform to do it.

 ### Community 
 > Like minded people gather because they enjoy the same content. Or maybe it's just that twitch chat is something otherworldly.
 
 ### Opportunities, Risks and Choices
 > Because that's compulsory

###### i sure hope we aren't marked based on my design skills
